package dbfs.pack;

public class ErrorCodes {
	// TODO Write error codes.
}
